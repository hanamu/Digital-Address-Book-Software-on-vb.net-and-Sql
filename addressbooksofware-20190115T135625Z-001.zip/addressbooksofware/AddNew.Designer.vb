﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddNew
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Groups = New System.Windows.Forms.TextBox()
        Me.AddImage = New System.Windows.Forms.Button()
        Me.DateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.BloodGroup = New System.Windows.Forms.TextBox()
        Me.label = New System.Windows.Forms.Label()
        Me.ProfilePic = New System.Windows.Forms.PictureBox()
        Me.LastName = New System.Windows.Forms.TextBox()
        Me.FirstName = New System.Windows.Forms.TextBox()
        Me.MiddleName = New System.Windows.Forms.TextBox()
        Me.NickName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.YoutubeID = New System.Windows.Forms.TextBox()
        Me.TwitterID = New System.Windows.Forms.TextBox()
        Me.FacebookID = New System.Windows.Forms.TextBox()
        Me.EMail = New System.Windows.Forms.TextBox()
        Me.MobileNo2 = New System.Windows.Forms.TextBox()
        Me.MobileNo1 = New System.Windows.Forms.TextBox()
        Me.PhoneNo = New System.Windows.Forms.TextBox()
        Me.label50 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.GSTN = New System.Windows.Forms.TextBox()
        Me.CompanyAddress = New System.Windows.Forms.TextBox()
        Me.CompanyMobileNo = New System.Windows.Forms.TextBox()
        Me.CompanyNo = New System.Windows.Forms.TextBox()
        Me.CompanyName = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Address = New System.Windows.Forms.TextBox()
        Me.Zip = New System.Windows.Forms.TextBox()
        Me.State = New System.Windows.Forms.TextBox()
        Me.City = New System.Windows.Forms.TextBox()
        Me.Country = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Notes = New System.Windows.Forms.TextBox()
        Me.savecontacts = New System.Windows.Forms.Button()
        Me.cancel = New System.Windows.Forms.Button()
        Me.exitaddnew = New System.Windows.Forms.Button()
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.ContactID = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout()
        CType(Me.ProfilePic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.ContactID)
        Me.Panel1.Controls.Add(Me.Label28)
        Me.Panel1.Controls.Add(Me.Groups)
        Me.Panel1.Controls.Add(Me.AddImage)
        Me.Panel1.Controls.Add(Me.DateOfBirth)
        Me.Panel1.Controls.Add(Me.BloodGroup)
        Me.Panel1.Controls.Add(Me.label)
        Me.Panel1.Controls.Add(Me.ProfilePic)
        Me.Panel1.Controls.Add(Me.LastName)
        Me.Panel1.Controls.Add(Me.FirstName)
        Me.Panel1.Controls.Add(Me.MiddleName)
        Me.Panel1.Controls.Add(Me.NickName)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(12, 48)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(566, 313)
        Me.Panel1.TabIndex = 0
        Me.Panel1.Tag = "Personal Details"
        '
        'Groups
        '
        Me.Groups.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Groups.Location = New System.Drawing.Point(205, 188)
        Me.Groups.Multiline = True
        Me.Groups.Name = "Groups"
        Me.Groups.Size = New System.Drawing.Size(159, 27)
        Me.Groups.TabIndex = 24
        '
        'AddImage
        '
        Me.AddImage.Location = New System.Drawing.Point(426, 213)
        Me.AddImage.Name = "AddImage"
        Me.AddImage.Size = New System.Drawing.Size(75, 23)
        Me.AddImage.TabIndex = 23
        Me.AddImage.Text = "add image"
        Me.AddImage.UseVisualStyleBackColor = True
        '
        'DateOfBirth
        '
        Me.DateOfBirth.Location = New System.Drawing.Point(205, 230)
        Me.DateOfBirth.Name = "DateOfBirth"
        Me.DateOfBirth.Size = New System.Drawing.Size(159, 20)
        Me.DateOfBirth.TabIndex = 14
        '
        'BloodGroup
        '
        Me.BloodGroup.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BloodGroup.Location = New System.Drawing.Point(205, 266)
        Me.BloodGroup.Multiline = True
        Me.BloodGroup.Name = "BloodGroup"
        Me.BloodGroup.Size = New System.Drawing.Size(159, 27)
        Me.BloodGroup.TabIndex = 13
        '
        'label
        '
        Me.label.AutoSize = True
        Me.label.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label.Location = New System.Drawing.Point(15, 269)
        Me.label.Name = "label"
        Me.label.Size = New System.Drawing.Size(170, 24)
        Me.label.TabIndex = 10
        Me.label.Text = "Blood Group     :"
        '
        'ProfilePic
        '
        Me.ProfilePic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ProfilePic.Image = Global.addressbooksofware.My.Resources.Resources.addimages
        Me.ProfilePic.Location = New System.Drawing.Point(386, 47)
        Me.ProfilePic.Name = "ProfilePic"
        Me.ProfilePic.Size = New System.Drawing.Size(168, 142)
        Me.ProfilePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ProfilePic.TabIndex = 9
        Me.ProfilePic.TabStop = False
        '
        'LastName
        '
        Me.LastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LastName.Location = New System.Drawing.Point(205, 148)
        Me.LastName.Multiline = True
        Me.LastName.Name = "LastName"
        Me.LastName.Size = New System.Drawing.Size(159, 27)
        Me.LastName.TabIndex = 7
        '
        'FirstName
        '
        Me.FirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FirstName.Location = New System.Drawing.Point(205, 76)
        Me.FirstName.Multiline = True
        Me.FirstName.Name = "FirstName"
        Me.FirstName.Size = New System.Drawing.Size(159, 27)
        Me.FirstName.TabIndex = 6
        '
        'MiddleName
        '
        Me.MiddleName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MiddleName.Location = New System.Drawing.Point(205, 115)
        Me.MiddleName.Multiline = True
        Me.MiddleName.Name = "MiddleName"
        Me.MiddleName.Size = New System.Drawing.Size(159, 27)
        Me.MiddleName.TabIndex = 6
        '
        'NickName
        '
        Me.NickName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NickName.Location = New System.Drawing.Point(205, 43)
        Me.NickName.Multiline = True
        Me.NickName.Name = "NickName"
        Me.NickName.Size = New System.Drawing.Size(159, 27)
        Me.NickName.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(11, 47)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(170, 24)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Nick Name       :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(15, 230)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(169, 24)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Date Of Birth   :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(18, 189)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(164, 24)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Group             :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(16, 151)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(166, 24)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Last Name       :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(11, 118)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(170, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Middle Name    :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 79)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(171, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "First Name       :"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.YoutubeID)
        Me.Panel2.Controls.Add(Me.TwitterID)
        Me.Panel2.Controls.Add(Me.FacebookID)
        Me.Panel2.Controls.Add(Me.EMail)
        Me.Panel2.Controls.Add(Me.MobileNo2)
        Me.Panel2.Controls.Add(Me.MobileNo1)
        Me.Panel2.Controls.Add(Me.PhoneNo)
        Me.Panel2.Controls.Add(Me.label50)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Location = New System.Drawing.Point(12, 416)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(415, 273)
        Me.Panel2.TabIndex = 1
        '
        'YoutubeID
        '
        Me.YoutubeID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.YoutubeID.Location = New System.Drawing.Point(196, 232)
        Me.YoutubeID.Name = "YoutubeID"
        Me.YoutubeID.Size = New System.Drawing.Size(159, 22)
        Me.YoutubeID.TabIndex = 15
        '
        'TwitterID
        '
        Me.TwitterID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TwitterID.Location = New System.Drawing.Point(196, 190)
        Me.TwitterID.Name = "TwitterID"
        Me.TwitterID.Size = New System.Drawing.Size(159, 22)
        Me.TwitterID.TabIndex = 14
        '
        'FacebookID
        '
        Me.FacebookID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FacebookID.Location = New System.Drawing.Point(196, 149)
        Me.FacebookID.Name = "FacebookID"
        Me.FacebookID.Size = New System.Drawing.Size(159, 22)
        Me.FacebookID.TabIndex = 13
        '
        'EMail
        '
        Me.EMail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EMail.Location = New System.Drawing.Point(196, 112)
        Me.EMail.Name = "EMail"
        Me.EMail.Size = New System.Drawing.Size(159, 22)
        Me.EMail.TabIndex = 12
        '
        'MobileNo2
        '
        Me.MobileNo2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MobileNo2.Location = New System.Drawing.Point(196, 77)
        Me.MobileNo2.Name = "MobileNo2"
        Me.MobileNo2.Size = New System.Drawing.Size(159, 22)
        Me.MobileNo2.TabIndex = 11
        '
        'MobileNo1
        '
        Me.MobileNo1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MobileNo1.Location = New System.Drawing.Point(196, 44)
        Me.MobileNo1.Name = "MobileNo1"
        Me.MobileNo1.Size = New System.Drawing.Size(159, 22)
        Me.MobileNo1.TabIndex = 10
        '
        'PhoneNo
        '
        Me.PhoneNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PhoneNo.Location = New System.Drawing.Point(196, 12)
        Me.PhoneNo.Name = "PhoneNo"
        Me.PhoneNo.Size = New System.Drawing.Size(159, 22)
        Me.PhoneNo.TabIndex = 9
        '
        'label50
        '
        Me.label50.AutoSize = True
        Me.label50.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label50.Location = New System.Drawing.Point(11, 234)
        Me.label50.Name = "label50"
        Me.label50.Size = New System.Drawing.Size(122, 18)
        Me.label50.TabIndex = 8
        Me.label50.Text = "Youtube        :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(13, 189)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(120, 18)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Twitter-Id     :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(13, 148)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(121, 18)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "Facebook-Id   :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(15, 111)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(120, 18)
        Me.Label12.TabIndex = 5
        Me.Label12.Text = "E - Mail       :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(13, 77)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(122, 18)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Mobile No 2   :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(15, 44)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(122, 18)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "Mobile No 1   :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(16, 11)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(121, 18)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Phone No      :"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.GSTN)
        Me.Panel3.Controls.Add(Me.CompanyAddress)
        Me.Panel3.Controls.Add(Me.CompanyMobileNo)
        Me.Panel3.Controls.Add(Me.CompanyNo)
        Me.Panel3.Controls.Add(Me.CompanyName)
        Me.Panel3.Controls.Add(Me.Label20)
        Me.Panel3.Controls.Add(Me.Label19)
        Me.Panel3.Controls.Add(Me.Label18)
        Me.Panel3.Controls.Add(Me.Label17)
        Me.Panel3.Controls.Add(Me.Label16)
        Me.Panel3.Location = New System.Drawing.Point(739, 48)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(516, 237)
        Me.Panel3.TabIndex = 2
        '
        'GSTN
        '
        Me.GSTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GSTN.Location = New System.Drawing.Point(273, 188)
        Me.GSTN.Multiline = True
        Me.GSTN.Name = "GSTN"
        Me.GSTN.Size = New System.Drawing.Size(208, 25)
        Me.GSTN.TabIndex = 10
        '
        'CompanyAddress
        '
        Me.CompanyAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CompanyAddress.Location = New System.Drawing.Point(273, 144)
        Me.CompanyAddress.Multiline = True
        Me.CompanyAddress.Name = "CompanyAddress"
        Me.CompanyAddress.Size = New System.Drawing.Size(208, 25)
        Me.CompanyAddress.TabIndex = 9
        '
        'CompanyMobileNo
        '
        Me.CompanyMobileNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CompanyMobileNo.Location = New System.Drawing.Point(273, 98)
        Me.CompanyMobileNo.Multiline = True
        Me.CompanyMobileNo.Name = "CompanyMobileNo"
        Me.CompanyMobileNo.Size = New System.Drawing.Size(211, 29)
        Me.CompanyMobileNo.TabIndex = 8
        '
        'CompanyNo
        '
        Me.CompanyNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CompanyNo.Location = New System.Drawing.Point(273, 60)
        Me.CompanyNo.Multiline = True
        Me.CompanyNo.Name = "CompanyNo"
        Me.CompanyNo.Size = New System.Drawing.Size(211, 27)
        Me.CompanyNo.TabIndex = 7
        '
        'CompanyName
        '
        Me.CompanyName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CompanyName.Location = New System.Drawing.Point(273, 17)
        Me.CompanyName.Multiline = True
        Me.CompanyName.Name = "CompanyName"
        Me.CompanyName.Size = New System.Drawing.Size(211, 25)
        Me.CompanyName.TabIndex = 6
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(21, 195)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(235, 25)
        Me.Label20.TabIndex = 4
        Me.Label20.Text = "GSTN                   :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(9, 144)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(245, 25)
        Me.Label19.TabIndex = 3
        Me.Label19.Text = "Company Address     :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(15, 102)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(243, 25)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "Mobile No              :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(7, 62)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(260, 25)
        Me.Label17.TabIndex = 1
        Me.Label17.Text = "Company Phone No   : "
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(15, 21)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(246, 25)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "Company Name        :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(93, 9)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(336, 25)
        Me.Label14.TabIndex = 4
        Me.Label14.Text = "--------Personal Details ----------"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(76, 373)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(360, 25)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "---------- Accessbility ----------------"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(844, 9)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(318, 25)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "--------Company Details--------"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(808, 307)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(314, 25)
        Me.Label22.TabIndex = 11
        Me.Label22.Text = "------------Address---------------"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(800, 499)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(299, 25)
        Me.Label23.TabIndex = 14
        Me.Label23.Text = "-------- Note --------------------"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(18, 13)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(118, 25)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "Country  :"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Address)
        Me.Panel4.Controls.Add(Me.Zip)
        Me.Panel4.Controls.Add(Me.State)
        Me.Panel4.Controls.Add(Me.City)
        Me.Panel4.Controls.Add(Me.Country)
        Me.Panel4.Controls.Add(Me.Label27)
        Me.Panel4.Controls.Add(Me.Label26)
        Me.Panel4.Controls.Add(Me.Label25)
        Me.Panel4.Controls.Add(Me.Label24)
        Me.Panel4.Controls.Add(Me.Label21)
        Me.Panel4.Location = New System.Drawing.Point(739, 343)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(516, 148)
        Me.Panel4.TabIndex = 9
        '
        'Address
        '
        Me.Address.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Address.Location = New System.Drawing.Point(137, 103)
        Me.Address.Multiline = True
        Me.Address.Name = "Address"
        Me.Address.Size = New System.Drawing.Size(376, 29)
        Me.Address.TabIndex = 15
        '
        'Zip
        '
        Me.Zip.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Zip.Location = New System.Drawing.Point(373, 47)
        Me.Zip.Multiline = True
        Me.Zip.Name = "Zip"
        Me.Zip.Size = New System.Drawing.Size(128, 29)
        Me.Zip.TabIndex = 14
        '
        'State
        '
        Me.State.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.State.Location = New System.Drawing.Point(371, 13)
        Me.State.Multiline = True
        Me.State.Name = "State"
        Me.State.Size = New System.Drawing.Size(130, 29)
        Me.State.TabIndex = 13
        '
        'City
        '
        Me.City.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.City.Location = New System.Drawing.Point(137, 55)
        Me.City.Multiline = True
        Me.City.Name = "City"
        Me.City.Size = New System.Drawing.Size(130, 29)
        Me.City.TabIndex = 12
        '
        'Country
        '
        Me.Country.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Country.Location = New System.Drawing.Point(137, 13)
        Me.Country.Multiline = True
        Me.Country.Name = "Country"
        Me.Country.Size = New System.Drawing.Size(130, 29)
        Me.Country.TabIndex = 11
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(21, 103)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(117, 25)
        Me.Label27.TabIndex = 5
        Me.Label27.Text = "Address  :"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(289, 51)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(78, 25)
        Me.Label26.TabIndex = 4
        Me.Label26.Text = "Zip   :"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(27, 56)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(109, 25)
        Me.Label25.TabIndex = 3
        Me.Label25.Text = "City      :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Modern No. 20", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(286, 13)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(79, 25)
        Me.Label24.TabIndex = 2
        Me.Label24.Text = "State :"
        '
        'Notes
        '
        Me.Notes.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Notes.Location = New System.Drawing.Point(739, 529)
        Me.Notes.Multiline = True
        Me.Notes.Name = "Notes"
        Me.Notes.Size = New System.Drawing.Size(510, 110)
        Me.Notes.TabIndex = 19
        '
        'savecontacts
        '
        Me.savecontacts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.savecontacts.Location = New System.Drawing.Point(530, 488)
        Me.savecontacts.Name = "savecontacts"
        Me.savecontacts.Size = New System.Drawing.Size(118, 36)
        Me.savecontacts.TabIndex = 20
        Me.savecontacts.Text = "Save"
        Me.savecontacts.UseVisualStyleBackColor = True
        '
        'cancel
        '
        Me.cancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cancel.Location = New System.Drawing.Point(530, 534)
        Me.cancel.Name = "cancel"
        Me.cancel.Size = New System.Drawing.Size(118, 36)
        Me.cancel.TabIndex = 21
        Me.cancel.Text = "Cancel"
        Me.cancel.UseVisualStyleBackColor = True
        '
        'exitaddnew
        '
        Me.exitaddnew.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exitaddnew.Location = New System.Drawing.Point(530, 587)
        Me.exitaddnew.Name = "exitaddnew"
        Me.exitaddnew.Size = New System.Drawing.Size(118, 36)
        Me.exitaddnew.TabIndex = 22
        Me.exitaddnew.Text = "Exit"
        Me.exitaddnew.UseVisualStyleBackColor = True
        '
        'SqlConnection1
        '
        Me.SqlConnection1.ConnectionString = "Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True"
        Me.SqlConnection1.FireInfoMessageEventOnUserErrors = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.addressbooksofware.My.Resources.Resources.note
        Me.PictureBox5.Location = New System.Drawing.Point(739, 497)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(55, 31)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 13
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.addressbooksofware.My.Resources.Resources.home
        Me.PictureBox4.Location = New System.Drawing.Point(739, 291)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(63, 41)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 12
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.addressbooksofware.My.Resources.Resources.company
        Me.PictureBox3.Location = New System.Drawing.Point(765, 2)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(74, 40)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 7
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.addressbooksofware.My.Resources.Resources.socialmedia
        Me.PictureBox2.Location = New System.Drawing.Point(15, 367)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(58, 43)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 5
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.addressbooksofware.My.Resources.Resources.cont1
        Me.PictureBox1.Location = New System.Drawing.Point(12, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(75, 40)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(17, 17)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(166, 24)
        Me.Label28.TabIndex = 25
        Me.Label28.Text = "Contact ID       :"
        '
        'ContactID
        '
        Me.ContactID.Location = New System.Drawing.Point(205, 10)
        Me.ContactID.Multiline = True
        Me.ContactID.Name = "ContactID"
        Me.ContactID.Size = New System.Drawing.Size(159, 27)
        Me.ContactID.TabIndex = 26
        '
        'AddNew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.ClientSize = New System.Drawing.Size(1284, 701)
        Me.Controls.Add(Me.exitaddnew)
        Me.Controls.Add(Me.cancel)
        Me.Controls.Add(Me.savecontacts)
        Me.Controls.Add(Me.Notes)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "AddNew"
        Me.Text = "addnew"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.ProfilePic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents LastName As System.Windows.Forms.TextBox
    Friend WithEvents FirstName As System.Windows.Forms.TextBox
    Friend WithEvents MiddleName As System.Windows.Forms.TextBox
    Friend WithEvents NickName As System.Windows.Forms.TextBox
    Friend WithEvents label50 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents YoutubeID As System.Windows.Forms.TextBox
    Friend WithEvents TwitterID As System.Windows.Forms.TextBox
    Friend WithEvents FacebookID As System.Windows.Forms.TextBox
    Friend WithEvents EMail As System.Windows.Forms.TextBox
    Friend WithEvents MobileNo2 As System.Windows.Forms.TextBox
    Friend WithEvents MobileNo1 As System.Windows.Forms.TextBox
    Friend WithEvents PhoneNo As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents CompanyAddress As System.Windows.Forms.TextBox
    Friend WithEvents CompanyMobileNo As System.Windows.Forms.TextBox
    Friend WithEvents CompanyNo As System.Windows.Forms.TextBox
    Friend WithEvents CompanyName As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents ProfilePic As System.Windows.Forms.PictureBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Address As System.Windows.Forms.TextBox
    Friend WithEvents Zip As System.Windows.Forms.TextBox
    Friend WithEvents State As System.Windows.Forms.TextBox
    Friend WithEvents City As System.Windows.Forms.TextBox
    Friend WithEvents Country As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Notes As System.Windows.Forms.TextBox
    Friend WithEvents savecontacts As System.Windows.Forms.Button
    Friend WithEvents cancel As System.Windows.Forms.Button
    Friend WithEvents exitaddnew As System.Windows.Forms.Button
    Friend WithEvents label As System.Windows.Forms.Label
    Friend WithEvents BloodGroup As System.Windows.Forms.TextBox
    Friend WithEvents GSTN As System.Windows.Forms.TextBox
    Friend WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    Friend WithEvents DateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents AddImage As System.Windows.Forms.Button
    Friend WithEvents Groups As System.Windows.Forms.TextBox
    Friend WithEvents ContactID As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
End Class
