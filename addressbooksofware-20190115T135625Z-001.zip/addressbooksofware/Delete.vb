﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Delete
    Public cs As New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
    Dim con As SqlConnection
    Dim cmd As SqlCommand
  
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click


        Dim reader As SqlDataReader
        Dim command As New SqlCommand

        Try
            cs.Open()
            Dim query As String
            query = "Delete from addnew where NickName='" & TextBox1.Text & "' "
            command = New SqlCommand(query, cs)
            reader = command.ExecuteReader
            MessageBox.Show("Contact Deleted Succsfully !")
            filterrecords("")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            cs.Dispose()
        End Try
        cs.Close()

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        filterrecords("")
        Me.Close()
    End Sub

    Private Sub Delete_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim connection As New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
        Dim adapter As New SqlDataAdapter("select NickName,ProfilePic from addnew", connection)
        Dim table As New DataTable()
        adapter.Fill(table)
        DataGridView1.DataSource = table
        DataGridView1.AutoGenerateColumns = False
        DataGridView1.ReadOnly = True
    End Sub
    Sub filterrecords(ByVal search As String)
        Dim con As SqlConnection
        Dim cmd As SqlCommand
        con = New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
        Dim query As String = "select * from addnew"
        cmd = New SqlCommand(query, con)
        Dim da = New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub


End Class

