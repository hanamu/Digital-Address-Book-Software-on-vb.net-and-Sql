﻿Imports System.Data.SqlClient
Public Class LoginForm1

    Private Sub OK_Click(sender As System.Object, e As System.EventArgs) Handles OK.Click
        Dim cmd As SqlCommand
        Dim conn As SqlConnection
        Dim sql = "SELECT username,password FROM logintable WHERE username = '" & username.Text & "' AND password = '" & password.Text & "'"

        conn = New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")

        conn.Open()



        cmd = New SqlCommand(sql, conn)
        Dim dr As SqlDataReader = cmd.ExecuteReader



        Try

            If dr.Read = False Then

                MessageBox.Show("Authentication Failed...")

            Else

                MessageBox.Show("Login Successful...")
                Me.Hide()
                home.Show()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try


        If conn.State <> ConnectionState.Closed Then

            conn.Close()

        End If

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Register.Show()
    End Sub
    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

   
End Class
