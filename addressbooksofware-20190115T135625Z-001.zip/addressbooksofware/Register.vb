﻿Imports System.Data.SqlClient
Public Class Register



    Dim sqlLink As SqlConnection
    Private Sub registerform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        sqlLink = New SqlConnection()
        sqlLink.ConnectionString = ("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")




    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            sqlLink.Open()
            If RegisterUserName.Text = "" Then
                MsgBox("You did not enter a Username !")
                sqlLink.Close()
                Return
            ElseIf RegisterPassword.Text = "" Then
                MsgBox("You did not enter a Password !")
                sqlLink.Close()
                Return
            Else
                MsgBox("You have successfully registered, you can log in now !")
            End If
            Dim sqlOrder As New SqlCommand()
            sqlOrder.Connection = sqlLink
            sqlOrder.CommandText = "INSERT INTO logintable(username,password) " &"VALUES('" & RegisterUserName.Text & "','" & RegisterPassword.Text & "')"
            sqlOrder.ExecuteNonQuery()
        Catch EX As Exception
            MsgBox("An error occurred: " & EX.Message)
        Finally
            sqlLink.Close()
        End Try
        Me.Close()
        LoginForm1.Show()
    End Sub
End Class
