﻿Imports System.Data
Imports System.Data.SqlClient
Public Class home
    Dim connection As New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
    Dim command As SqlCommand

    Private Sub addnewcontacts_Click(sender As System.Object, e As System.EventArgs) Handles addnewcontacts.Click
        AddNew.Show()
    End Sub

    Private Sub view_Click(sender As System.Object, e As System.EventArgs) Handles view.Click
        viewcontacts.Show()
    End Sub

    Private Sub other_Click(sender As System.Object, e As System.EventArgs) Handles other.Click
        others.Show()
    End Sub

    Private Sub exithome_Click(sender As System.Object, e As System.EventArgs) Handles exithome.Click
        Me.Close()
    End Sub

    Private Sub infomacha_Click(sender As System.Object, e As System.EventArgs) Handles infomacha.Click
        info.Show()
    End Sub

    Private Sub home_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim connection As New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
        Dim adapter As New SqlDataAdapter("select NickName,DateOfBirth,MobileNo1,Groups,ProfilePic from addnew", connection)
        Dim table As New DataTable()
        adapter.Fill(table)
        DataGridView1.DataSource = table
        DataGridView1.AutoGenerateColumns = False
        DataGridView1.ReadOnly = True

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Filterdata(TextBox1.Text)
    End Sub
    Public Sub Filterdata(ByVal valuetoSearch As String)

        Dim str As String = ("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")

        Dim con As New SqlConnection(str)

        Dim cmd As New SqlCommand("select * from addnew where NickName like '%" + TextBox1.Text + "%'", con)



        Dim Adpt As New SqlDataAdapter(cmd)

        Dim ds As New DataSet()

        If (Adpt.Fill(ds, "addnew")) Then

            DataGridView1.DataSource = ds.Tables(0)

        End If
    End Sub
    Sub filterrecords(ByVal search As String)
        connection = New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
        Dim query As String = "select * from addnew"
        Command = New SqlCommand(query, connection)
        Dim da = New SqlDataAdapter(command)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Refresh_Click(sender As System.Object, e As System.EventArgs) Handles Refresh.Click
        filterrecords("")
    End Sub
End Class