﻿Imports System.Data.SqlClient
Module Module1
    Public conn As New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
    Public cmd As New Data.SqlClient.SqlCommand
End Module
