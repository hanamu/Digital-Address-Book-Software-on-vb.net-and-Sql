﻿Imports System.Data
Imports System.Data.SqlClient
Public Class viewcontacts
    Dim connection As New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
    Dim command As SqlCommand

    Private cs As New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
    Private da As New SqlDataAdapter("select * from addnew", cs)
    Private ds As New DataSet
    Private cmb As New SqlCommandBuilder
    Dim con As SqlConnection
    Dim cmd As SqlCommand


    Private Sub viewcontacts_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Try
            da.Fill(ds, "addnew")
            DataGridView1.DataSource = ds.Tables("addnew")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles exitviewcontacts.Click

        Me.Close()
    End Sub



    Private Sub deletecontacts_Click_1(sender As System.Object, e As System.EventArgs) Handles deletecontacts.Click
        Delete.Show()
    End Sub


    Private Sub editcontacts_Click(sender As System.Object, e As System.EventArgs) Handles editcontacts.Click
        updatecontact.Show()
    End Sub
    Sub filterrecords(ByVal search As String)
        connection = New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
        Dim query As String = "select * from addnew"
        command = New SqlCommand(query, connection)
        Dim da = New SqlDataAdapter(command)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

   
    Private Sub Refreshview_Click(sender As System.Object, e As System.EventArgs) Handles Refreshview.Click
        filterrecords("")
    End Sub
End Class
