﻿Public Class others

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles closeothers.Click
        Me.Close()
    End Sub

    Private Sub exportcontacts_Click(sender As System.Object, e As System.EventArgs) Handles exportcontacts.Click
        export.Show()
    End Sub

    Private Sub printcontacts_Click(sender As System.Object, e As System.EventArgs) Handles printcontacts.Click
        PrintContact.Show()
    End Sub
End Class