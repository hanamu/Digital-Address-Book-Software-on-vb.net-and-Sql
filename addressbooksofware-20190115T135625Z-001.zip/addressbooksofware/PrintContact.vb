﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Drawing.Printing
Public Class PrintContact
    Private Sub PrintContact_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim connection As New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
        Dim adapter As New SqlDataAdapter("select NickName,MobileNo1,ProfilePic from addnew", connection)
        Dim table As New DataTable()
        adapter.Fill(table)
        DataGridView1.DataSource = table
        DataGridView1.AutoGenerateColumns = False
        DataGridView1.ReadOnly = True

    End Sub



    Dim cs As New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
    Dim da As New SqlDataAdapter("select * from addnew", cs)
    Dim ds As New DataSet
    Dim con As SqlConnection
    Dim strcon
    Private Sub print_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            da.Fill(ds, "addnew")
            DataGridView1.DataSource = ds.Tables("addnew")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private bitmap As Bitmap

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim bm As New Bitmap(Me.DataGridView1.Width, Me.DataGridView1.Height)
        DataGridView1.DrawToBitmap(bm, New Rectangle(0, 0, Me.DataGridView1.Width, Me.DataGridView1.Height))
        e.Graphics.DrawImage(bm, 0, 0)
    End Sub

    Private Sub Print_Click(sender As System.Object, e As System.EventArgs)
        PrintDocument1.Print()
    End Sub

   
    Private Sub hide_Click(sender As System.Object, e As System.EventArgs) Handles hide.Click
        Me.Close()
    End Sub
End Class


