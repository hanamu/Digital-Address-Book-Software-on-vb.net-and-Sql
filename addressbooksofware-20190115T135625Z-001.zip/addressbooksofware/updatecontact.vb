﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Public Class updatecontact

    Dim con As New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
    Dim command As SqlCommand
    Sub filterrecords(ByVal search As String)
        con = New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
        Dim query As String = "select * from addnew"
        command = New SqlCommand(query, con)
        Dim da = New SqlDataAdapter(command)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        filterrecords("")
    End Sub

    Private Sub DataGridView1_MouseClick(sender As Object, e As MouseEventArgs) Handles DataGridView1.MouseClick
        Dim ms As New MemoryStream
        ProfilePic.Image.Save(ms, ProfilePic.Image.RawFormat)
        Dim i As Integer

        i = DataGridView1.CurrentRow.Index
        Me.ContactID.Text = DataGridView1.Item(0, i).Value
        Me.NickName.Text = DataGridView1.Item(1, i).Value
        Me.FirstName.Text = DataGridView1.Item(2, i).Value
        Me.MiddleName.Text = DataGridView1.Item(3, i).Value
        Me.LastName.Text = DataGridView1.Item(4, i).Value
        Me.Groups.Text = DataGridView1.Item(5, i).Value
        Me.DateOfBirth.Text = DataGridView1.Item(6, i).Value
        Me.BloodGroup.Text = DataGridView1.Item(7, i).Value
        Me.PhoneNo.Text = DataGridView1.Item(8, i).Value
        Me.MobileNo1.Text = DataGridView1.Item(9, i).Value
        Me.MobileNo2.Text = DataGridView1.Item(10, i).Value
        Me.EMail.Text = DataGridView1.Item(11, i).Value
        Me.FacebookID.Text = DataGridView1.Item(12, i).Value
        Me.TwitterID.Text = DataGridView1.Item(13, i).Value
        Me.YoutubeID.Text = DataGridView1.Item(14, i).Value
        Me.CompanyName.Text = DataGridView1.Item(15, i).Value
        Me.CompanyNo.Text = DataGridView1.Item(16, i).Value
        Me.CompanyMobileNo.Text = DataGridView1.Item(17, i).Value
        Me.CompanyAddress.Text = DataGridView1.Item(18, i).Value
        Me.GSTN.Text = DataGridView1.Item(19, i).Value
        Me.Country.Text = DataGridView1.Item(20, i).Value
        Me.State.Text = DataGridView1.Item(21, i).Value
        Me.City.Text = DataGridView1.Item(22, i).Value
        Me.Zip.Text = DataGridView1.Item(23, i).Value
        Me.Address.Text = DataGridView1.Item(24, i).Value
        Me.Notes.Text = DataGridView1.Item(25, i).Value
        Me.ProfilePic.Image = DataGridView1.Item(26, i).Value
       


    End Sub


    Private Sub exitupdtaecontact_Click(sender As System.Object, e As System.EventArgs) Handles exitupdtaecontact.Click
        Me.Close()
    End Sub

    Private Sub updatecontacts_Click(sender As System.Object, e As System.EventArgs) Handles updatecontacts.Click
        con = New SqlConnection("Data Source=DESKTOP-NOE85H4;Initial Catalog=addressbook;Integrated Security=True")
        Dim updatequery As String = "Update addnew set NickName=@NickName,FirstName=@FirstName,MiddleName=@MiddleName,LastName=@LastName,Groups=@Groups,DateOfBirth=@DateOfBirth,BloodGroup=@BloodGroup,PhoneNo=@PhoneNo,MobileNo1=@MobileNo1,MobileNo2=@MobileNo2,EMail=@EMail,FacebookID=@FaceBookID,TwitterID=@TwitterID,YoutubeID=@YoutubeID,CompanyName=@CompanyName,CompanyNo=@CompanyNo,CompanyMobileNo=@CompanyMobileNo,CompanyAddress=@CompanyAddress,GSTN=@GSTN,Country=@Country,State=@State,City=@City,Zip=@Zip,Address=@Address,Notes=@Notes,ProfilePic=@ProfilePic where ContactID=@ContactID"
        Dim ms As New MemoryStream
        ProfilePic.Image.Save(ms, ProfilePic.Image.RawFormat)
        con.Open()
        command = New SqlCommand(updatequery, con)
        command.Parameters.Add("@ContactID", SqlDbType.NVarChar).Value = ContactID.Text
        command.Parameters.Add("@NickName", SqlDbType.NVarChar).Value = NickName.Text
        command.Parameters.Add("@FirstName", SqlDbType.NVarChar).Value = FirstName.Text
        command.Parameters.Add("@MiddleName", SqlDbType.NVarChar).Value = MiddleName.Text
        command.Parameters.Add("@LastName", SqlDbType.NVarChar).Value = LastName.Text
        command.Parameters.Add("@Groups", SqlDbType.NVarChar).Value = Groups.Text
        command.Parameters.Add("@DateOfBirth", SqlDbType.NVarChar).Value = DateOfBirth.Text
        command.Parameters.Add("@BloodGroup", SqlDbType.NVarChar).Value = BloodGroup.Text
        command.Parameters.Add("@PhoneNo", SqlDbType.NVarChar).Value = PhoneNo.Text
        command.Parameters.Add("@MobileNo1", SqlDbType.NVarChar).Value = MobileNo1.Text
        command.Parameters.Add("@MobileNo2", SqlDbType.NVarChar).Value = MobileNo2.Text
        command.Parameters.Add("@EMail", SqlDbType.NVarChar).Value = EMail.Text
        command.Parameters.Add("@FacebookID", SqlDbType.NVarChar).Value = FacebookID.Text
        command.Parameters.Add("@TwitterID", SqlDbType.NVarChar).Value = TwitterID.Text
        command.Parameters.Add("@YoutubeID", SqlDbType.NVarChar).Value = YoutubeID.Text
        command.Parameters.Add("@CompanyName", SqlDbType.NVarChar).Value = CompanyName.Text
        command.Parameters.Add("@CompanyNo", SqlDbType.NVarChar).Value = CompanyNo.Text
        command.Parameters.Add("@CompanyMobileNo", SqlDbType.NVarChar).Value = CompanyMobileNo.Text
        command.Parameters.Add("@CompanyAddress", SqlDbType.NVarChar).Value = CompanyAddress.Text
        command.Parameters.Add("@GSTN", SqlDbType.NVarChar).Value = GSTN.Text
        command.Parameters.Add("@Country", SqlDbType.NVarChar).Value = Country.Text
        command.Parameters.Add("@State", SqlDbType.NVarChar).Value = State.Text
        command.Parameters.Add("@City", SqlDbType.NVarChar).Value = City.Text
        command.Parameters.Add("@Zip", SqlDbType.NVarChar).Value = Zip.Text
        command.Parameters.Add("@Address", SqlDbType.NVarChar).Value = Address.Text
        command.Parameters.Add("@Notes", SqlDbType.NVarChar).Value = Notes.Text
        command.Parameters.Add("@ProfilePic ", SqlDbType.Image).Value = ms.ToArray()
        command.ExecuteNonQuery()
        MsgBox("Record updated successfully")
        filterrecords("")
        DataGridView1.RefreshEdit()

        con.Close()
    End Sub

   
End Class


