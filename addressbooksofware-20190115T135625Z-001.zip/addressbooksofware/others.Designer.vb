﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class others
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.printcontacts = New System.Windows.Forms.Button()
        Me.exportcontacts = New System.Windows.Forms.Button()
        Me.closeothers = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(66, 88)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(263, 31)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Print Your contacts"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(66, 216)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(400, 31)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Export Your  Contacts to CSV"
        '
        'printcontacts
        '
        Me.printcontacts.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.printcontacts.ForeColor = System.Drawing.Color.Black
        Me.printcontacts.Location = New System.Drawing.Point(579, 67)
        Me.printcontacts.Name = "printcontacts"
        Me.printcontacts.Size = New System.Drawing.Size(126, 60)
        Me.printcontacts.TabIndex = 2
        Me.printcontacts.Text = "Print"
        Me.printcontacts.UseVisualStyleBackColor = True
        '
        'exportcontacts
        '
        Me.exportcontacts.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exportcontacts.Location = New System.Drawing.Point(579, 190)
        Me.exportcontacts.Name = "exportcontacts"
        Me.exportcontacts.Size = New System.Drawing.Size(126, 57)
        Me.exportcontacts.TabIndex = 3
        Me.exportcontacts.Text = "Export"
        Me.exportcontacts.UseVisualStyleBackColor = True
        '
        'closeothers
        '
        Me.closeothers.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeothers.Location = New System.Drawing.Point(330, 331)
        Me.closeothers.Name = "closeothers"
        Me.closeothers.Size = New System.Drawing.Size(144, 39)
        Me.closeothers.TabIndex = 4
        Me.closeothers.Text = "Close"
        Me.closeothers.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.addressbooksofware.My.Resources.Resources._11165142351
        Me.PictureBox2.Location = New System.Drawing.Point(482, 190)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(100, 57)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 6
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.addressbooksofware.My.Resources.Resources._16225630_print_icon1
        Me.PictureBox1.Location = New System.Drawing.Point(482, 67)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 60)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'others
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 397)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.closeothers)
        Me.Controls.Add(Me.exportcontacts)
        Me.Controls.Add(Me.printcontacts)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.MaximizeBox = False
        Me.Name = "others"
        Me.Text = "others"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents printcontacts As System.Windows.Forms.Button
    Friend WithEvents exportcontacts As System.Windows.Forms.Button
    Friend WithEvents closeothers As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
End Class
