﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class viewcontacts
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.editcontacts = New System.Windows.Forms.Button()
        Me.deletecontacts = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection()
        Me.exitviewcontacts = New System.Windows.Forms.Button()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Refreshview = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'editcontacts
        '
        Me.editcontacts.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.editcontacts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.editcontacts.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.editcontacts.Location = New System.Drawing.Point(570, 561)
        Me.editcontacts.Name = "editcontacts"
        Me.editcontacts.Size = New System.Drawing.Size(102, 59)
        Me.editcontacts.TabIndex = 6
        Me.editcontacts.Text = " EDIT"
        Me.editcontacts.UseVisualStyleBackColor = False
        '
        'deletecontacts
        '
        Me.deletecontacts.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.deletecontacts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.deletecontacts.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deletecontacts.Location = New System.Drawing.Point(146, 561)
        Me.deletecontacts.Name = "deletecontacts"
        Me.deletecontacts.Size = New System.Drawing.Size(121, 59)
        Me.deletecontacts.TabIndex = 10
        Me.deletecontacts.Text = "DELETE"
        Me.deletecontacts.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(2, -1)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 100
        Me.DataGridView1.Size = New System.Drawing.Size(1282, 556)
        Me.DataGridView1.TabIndex = 12
        '
        'SqlConnection1
        '
        Me.SqlConnection1.FireInfoMessageEventOnUserErrors = False
        '
        'exitviewcontacts
        '
        Me.exitviewcontacts.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.exitviewcontacts.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exitviewcontacts.ForeColor = System.Drawing.Color.Black
        Me.exitviewcontacts.Location = New System.Drawing.Point(1005, 561)
        Me.exitviewcontacts.Name = "exitviewcontacts"
        Me.exitviewcontacts.Size = New System.Drawing.Size(123, 59)
        Me.exitviewcontacts.TabIndex = 13
        Me.exitviewcontacts.Text = "EXIT"
        Me.exitviewcontacts.UseVisualStyleBackColor = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.addressbooksofware.My.Resources.Resources.exit1
        Me.PictureBox3.Location = New System.Drawing.Point(945, 561)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(69, 59)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 16
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.addressbooksofware.My.Resources.Resources.delete
        Me.PictureBox2.Location = New System.Drawing.Point(93, 561)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(59, 59)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 15
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.addressbooksofware.My.Resources.Resources.edit
        Me.PictureBox1.Location = New System.Drawing.Point(509, 561)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(64, 59)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 14
        Me.PictureBox1.TabStop = False
        '
        'Refreshview
        '
        Me.Refreshview.Font = New System.Drawing.Font("OCR A Extended", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Refreshview.Location = New System.Drawing.Point(1187, 513)
        Me.Refreshview.Name = "Refreshview"
        Me.Refreshview.Size = New System.Drawing.Size(85, 30)
        Me.Refreshview.TabIndex = 17
        Me.Refreshview.Text = "Refresh"
        Me.Refreshview.UseVisualStyleBackColor = True
        '
        'viewcontacts
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1284, 632)
        Me.Controls.Add(Me.Refreshview)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.exitviewcontacts)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.deletecontacts)
        Me.Controls.Add(Me.editcontacts)
        Me.Name = "viewcontacts"
        Me.Text = "viewcontacts"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents editcontacts As System.Windows.Forms.Button
    Friend WithEvents deletecontacts As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    Friend WithEvents exitviewcontacts As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Refreshview As System.Windows.Forms.Button
End Class
